# File name: Datasets.txt
This file contains following information about TFBS datasets; name of original file, TF name, cell name, and other notifications.
Date of the last modification: Jan. 30, 2017

# File name: HERV_info.txt
This file contains following information about HERV/LRs; HERV/LR type, HERV/LR family, copy number, animal groups that share the orthologous copies, consensus sequence used in this study, and origin of the consensus sequence.
Date of the last modification: Jan. 30, 2017

# File name: Positions_HERV-TFBSs_each_cell_type.txt
This file contains positions of HERV-TFBSs in human reference genome (hg19). In this file, HERV-TFBSs are separately described in each cell type.
Date of the last modification: Jan. 30, 2017

# File name: Positions_HERV-TFBSs_merged_cell_type.txt
This file contains positions of HERV-TFBSs in human reference genome (hg19). In this file, HERV-TFBSs that identified in distinct cell types were merged.
Date of the last modification: Jan. 30, 2017

# File name: Positions_HERV-DHSs.txt
This file contains positions of HERV-DHSs in human reference genome (hg19).
Date of the last modification: Jan. 30, 2017

# File name: Positions_HCREs_in_consensus_seq.txt
This file contains positions of HCREs in consensus sequence of the HERV/LRs. 
Date of the last modification: Jan. 30, 2017

# File name: Positions_HCREs_each_cell_type.txt
This file contains positions of HCREs in human reference genome (hg19). In this file, HCREs are separately described in each cell type.
Date of the last modification: Jan. 30, 2017

# File name: Positions_HCREs_merged_cell_type.txt
This file contains positions of HCREs in human reference genome (hg19). In this file, HCREs that identified in distinct cell types were merged.
Date of the last modification: Jan. 30, 2017

# File name: GO_HCREs_each_cell_type.txt
This file describes results of gene ontology (GO) enrichment analysis. The analysis was performed with GREAT program using a set of each type of HCREs. In the analysis, HCREs in respective cell types were used.
Date of the last modification: Jan. 30, 2017

# File name: GO_HCREs_merged _cell_type.txt
This file describes results of gene ontology (GO) enrichment analysis. The analysis was performed with GREAT program using a set of each type of HCREs. In the analysis, HCREs that merged among cell types were used.
Date of the last modification: Jan. 30, 2017

# File name: HERV-TFBS_info.txt
This file describes enrichments of TFBSs on HERV/LRs. Z scores calculated by count-based and depth-based permutation tests are written.
Date of the last modification: Jan. 30, 2017